AirSIM for F50 · 蓝牙可选件 bt-opt 1.0.3（内核 6.18.60）

这是可选件，不是主包。主包不带蓝牙驱动与 bluez，机器上没装过的话菜单里
不会有蓝牙页；装了才会出现。

装法（设备上，联网）：
    wget -O /tmp/btopt.tar.gz <Release 附件地址>
    tar xzf /tmp/btopt.tar.gz -C /tmp && sh /tmp/airsim-f50-bt-opt/install-bt.sh

装法（离线，先在电脑上下好再传上去）：同上，只是第一步换成 scp。

包内：root/ 下按设备绝对路径摆放，install-bt.sh 负责自检与铺文件。
本包只对内核 6.18.60 有效，驱动模块跟内核必须严丝合缝。
约 4696KB（未压缩）。

本包不做的事：
  * 「已配对设备」只读，不在网页里发起配对/删除（留给下一版）
  * 不提供音频协议栈（A2DP/HFP）：不能拿耳机放歌
