# F50 / mu300 在 OpenWrt 下启用蓝牙 —— 完整交付归档

设备：`192.168.77.1`（root 可登录）
系统：OpenWrt 25.12.5 / `armsr/armv8` / aarch64_generic / musl / 内核 **6.18.60** / 主机名 `mu300`
芯片：展锐 Unisoc（WCN combo，DT 里是 `sprd-marlin3`），WiFi + BT 共用一棵 WCN
日期：2026-11-09

---

## 0. 给接手这份工作的 AI：先看这三条

1. **`【仅在F50_B09测试，U30Air请自行尝试】F50音频与蓝牙修复_V1.0.0.zip` 是 Android 的 Magisk 模块**，
   靠 `insmod` / `setprop` / `svc bluetooth enable` 干活，**OpenWrt 上一条都用不了**，
   不要试图把它解压后照搬。它唯一有价值的信息是：展锐这颗 WCN 必须加载 `sprdbt_tty` 才有 `/dev/ttyBT0`。
2. 本机 OpenWrt **没有 opkg，只有 apk（apk-tools 3.0.5）**；仓库已在
   `/etc/apk/repositories.d/distfeeds.list` 配好（`25.12.5` / `aarch64_generic`）。
3. 固件 `/etc/apk/world` 里钉的是 `kernel=6.12.94`，**实际跑的是 6.18.60**。
   这是本机所有 kmod 类包必踩的坑，见第 6 节。

---

## 1. 最终状态（已验证）

| 项目 | 状态 |
|---|---|
| 驱动 | `sprdbt_tty` 已 `modprobe`，`/dev/ttyBT0`（488:0，root:dialout） |
| HCI | `hci0`，Type Primary / **Bus UART**，`UP RUNNING` |
| 地址 | `27:93:31:14:22:11` |
| 用户态 | BlueZ 5.83 + dbus（`bluetoothd` 常驻） |
| 名字 | `mu300`（`main.conf` 的 `Name`） |
| 自启 | `/etc/init.d/sprdbluetooth`（procd，START=61）+ `S60dbus` + `S62bluetoothd` |
| 累计错误 | 481+ events / 148+ commands / **errors: 0** |

开机顺序（`/etc/rc.d/`）：
`S60dbus` → `S61sprdbluetooth`（modprobe + btattach，常驻）→ `S62bluetoothd`（AutoEnable 上电）

> **待你确认的一件事**：本次交付**没有整机重启验证过**，只做了"kill btattach + `rmmod sprdbt_tty` 后重启服务"的冷启动模拟，能自动恢复。
> 重启后请自查：
> ```sh
> ls /sys/class/bluetooth          # 应有 hci0
> hciconfig -a                     # 应 UP RUNNING
> ps | grep -E "btattach|bluetoothd"
> bluetoothctl show | head -6
> ```
> 若 hci0 没起来，先看 `logread | grep -i sprd`，再手工 `/etc/init.d/sprdbluetooth restart`。

---

## 2. 控制器实测参数（2026-11-09 上机抓取）

```
HCI Version: 5.0 (0x9)      Revision: 0x400
LMP Version: 5.0 (0x9)      Subversion: 0x400
Manufacturer: 0x0000 (未填，正常现象)
Features: 0xff 0xff 0x8d 0xfe 0xdb 0x7d 0x3b 0xc3
ACL MTU: 1021:8   SCO MTU: 240:3
Packet type: DM1 DM3 DM5 DH1 DH3 DH5 HV1 HV2 HV3
```

特性位解读（对应用户关心的能力）：

| 能力 | 结论 |
|---|---|
| BR/EDR（经典蓝牙） | 支持（bit37=0） |
| BLE（低功耗） | 支持（bit38=1），且支持 LE/BR 同时工作（bit48=1） |
| **LE Audio（低功耗音频）** | **不支持**。LE Audio 需 5.2+ 的 ISO/LC3，这颗是 5.0 |
| EDR 带宽 | 2Mbps + 3Mbps（bit25/26/39/40），A2DP 带宽够 |
| 语音编码 | CVSD / A-law / u-law / 透明 SCO（bit11–16/19） |
| 增强 SCO | eSCO、EDR eSCO 2Mbps（bit45/56/57） |
| AFH / SSP / EIR | 全支持 |
| LE LL Privacy | **不支持**，`bluetoothd` 日志固定出现 `Failed to set privacy: Rejected (0x0b)`，无害 |

功能实测：
- 经典扫描 → `MITV-A593B`（小米电视）、`825267773的Redmi Note 5`（带完整 UUID 表）
- BLE 扫描 → `RM Magcooler 5pro`、`BYD BLE3`、`AIMA-1E4A50` 等一串
- HCI 直连（裸 H4 帧）：`Reset` → `Command Complete status=0`；`Read Local Version` 正常回包

---

## 3. 部署步骤（在一台干净固件上）

```sh
# 1) 加载展锐蓝牙 tty 驱动（固件里本来就有这个 ko，只是没加载）
modprobe sprdbt_tty             # 之后出现 /dev/ttyBT0

# 2) 装 BlueZ 用户态
apk update
apk add bluez-libs bluez-utils bluez-utils-extra bluez-daemon dbus
# 注意：会按依赖拉进 10 个 6.12.94 的 kmod-*，见第 6 节

# 3) 部署两个脚本（本包内已附）
cp sprd-bt-attach.sh /usr/sbin/sprd-bt-attach.sh && chmod 755 /usr/sbin/sprd-bt-attach.sh
cp sprdbluetooth.init /etc/init.d/sprdbluetooth && chmod 755 /etc/init.d/sprdbluetooth

# 4) BlueZ 配置
sed -i 's/^#AutoEnable=true/AutoEnable=true/' /etc/bluetooth/main.conf
sed -i 's/^#Name = BlueZ/Name = mu300/'      /etc/bluetooth/main.conf

# 5) 开机自启
/etc/init.d/dbus enable
/etc/init.d/sprdbluetooth enable
/etc/init.d/bluetoothd enable

# 6) 立即生效（顺序不能乱）
/etc/init.d/dbus restart
/etc/init.d/sprdbluetooth restart
/etc/init.d/bluetoothd restart
```

也可以直接跑包内的 `deploy.sh`（就是把上面这套串起来，**仅用于干净固件首次部署**）。

---

## 4. 两个关键实现细节

### 4.1 为什么一定要用 `btattach`，不能自己写 ioctl

对 `/dev/ttyBT0` 手工 `TIOCSETD` 设 `N_HCI`(15) **会成功**（`n_hci` 线路规程确实在，
内核 `CONFIG_BT_HCIUART=y` + `CONFIG_BT_HCIUART_H4=y`），但紧接着
`HCIUARTSETPROTO`（`_IOW('U',200,int)`，即 `0x400455C8`）**返回 `EPROTONOSUPPORT`(93)**，
协议号 0~15 逐个试过全部失败。
而系统 `btattach` 用同一套机制却能成功拉出 `hci0`。
→ **结论：attach 一律交给 `btattach`，不要自写 ioctl。**

### 4.2 rfkill 有两个蓝牙节点，只解一个是白解

```
/sys/class/rfkill/rfkill1  name=bluetooth  ← sprdbt_tty 注册的（管 WCN 上电）
/sys/class/rfkill/rfkill2  name=hci0       ← hci_uart attach 后出现的
```
只解 rfkill1 时 `hciconfig hci0 up` 报：
`Can't init device hci0: No error information (132)`
（musl 下 132 = `ERFKILL`，即被 rfkill 挡住）。
**两个都要写 0**，hci0 才真正 `UP RUNNING`。
另：`unblock` 后 dmesg 会看到 `WCN BASEstart_marlin [MARLIN_BLUETOOTH] power 1`，说明 WCN 真上电了。

---

## 5. 日常使用

```sh
bluetoothctl
[bluetooth]# scan on                 # 或 scan le
[bluetooth]# pair XX:XX:XX:XX:XX:XX
[bluetooth]# trust XX:XX:XX:XX:XX:XX
[bluetooth]# connect XX:XX:XX:XX:XX:XX
[bluetooth]# info  XX:XX:XX:XX:XX:XX
```

排查用：
```sh
hciconfig -a
bluetoothctl list / show / devices
bluetoothctl --timeout 15 scan on
logread | grep -i -E "bluetooth|sprd"
```
注：`hcitool lescan` 在这台固件上报 `Set scan parameters failed: I/O error`，
**换 `bluetoothctl --timeout N scan le` 就能扫到**，不要以为 LE 坏了。

---

## 6. 已知坑与遗留项

### 6.1 装 BlueZ 会带进 10 个"死"kmod
`bluez-libs` 依赖 `kmod-bluetooth`，而 world 钉的是 `kernel=6.12.94`，
于是 apk 从 kmods 仓库拉来 6.12.94 版的 `kmod-bluetooth / kmod-hid / kmod-input-*` 等，
落到 `/lib/modules/6.12.94/`。**运行时完全无效**（modprobe 只认 `uname -r`=6.18.60），
本次蓝牙一个 kmod 都没用到，纯噪声。**不要去 `modprobe` 它们**，也不要据此判断"蓝牙驱动是装包装的"。

### 6.2 音频能力（重要，别踩空）
硬件通路是有的：
- 声卡 `sprdphonesc2730`（FE_ST_NORMAL / VOICE / VOIP / FM / FAST 等前端）
- `/dev/audio_pipe_bthal`（蓝牙语音的内部音频管道）
- `snd_soc_sprd_codec_ump9620` 系列模块已加载

但用户态**一个音频软件都没有**（无 alsa-utils / pulseaudio / bluez-alsa）。仓库里有 `pulseaudio-17.0`、`alsa-utils-1.2.11`。

三条音频路径的判断：

| 路径 | 可行性 | 说明 |
|---|---|---|
| A2DP（音乐/媒体，设备作源推给耳机） | **可行** | 有 2Mbps EDR 够带宽；需装 `pulseaudio` + `module-bluetooth-discover` 配 ALSA 路由 |
| HFP/SCO（通话语音，接耳机打电话） | **风险高、不建议** | 这颗芯片 SCO 音频走片内 `audio_pipe_bthal` 直达 UMP9620 codec，**不走 HCI**；BlueZ 在 OpenWrt 上大概率拿不到 SCO 数据流，那套是 Android vendor HAL 才认 |
| LE Audio | **不可行** | 控制器 5.0，无 ISO/LC3 |

### 6.3 稳定性边界
已验证：服务被 kill、驱动 `rmmod` 后自动恢复；482 events 全 0 错误。
**未验证**：连接态长时间 soak（没有配对设备可测），以及整机重启（待用户确认）。
真要拿去做兜底，必须先做一次真实配对 + 至少 30 分钟挂机观察。

### 6.4 回滚
```sh
/etc/init.d/sprdbluetooth disable && /etc/init.d/sprdbluetooth stop
/etc/init.d/bluetoothd disable && /etc/init.d/bluetoothd stop
apk del bluez-daemon bluez-utils bluez-utils-extra dbus   # 连 BlueZ 一起撤
```

---

## 7. 本包文件清单

| 文件 | 说明 |
|---|---|
| `F50蓝牙在OpenWrt下的开启说明.md` | 本文档 |
| `sprd-bt-attach.sh` | 部署到 `/usr/sbin/`：modprobe → 等 `/dev/ttyBT0` → 解 rfkill → 后台等 hci0 出现再 up → `exec btattach` |
| `sprdbluetooth.init` | 部署成 `/etc/init.d/sprdbluetooth`：procd 服务，`START=61`，`respawn 3600 5 0` |
| `deploy.sh` | 干净固件上的一键部署脚本 |
| `F50蓝牙OpenWrt归档.zip` | 以上全部打包 |
